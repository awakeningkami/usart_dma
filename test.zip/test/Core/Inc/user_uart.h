#ifndef USER_UART_H
#define USER_UART_H 


#include "main.h"


extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;


extern DMA_HandleTypeDef g_dma_rx1_handle;
extern DMA_HandleTypeDef g_dma_tx1_handle;
extern DMA_HandleTypeDef g_dma_tx2_handle;

volatile extern uint8_t g_tx1_complete_flag;

extern uint8_t g_usart2_tx_buf[];                      /* ����2�������ݻ����� */

/***************************************************************************************/

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);


void usart1_receive(void);

void usart1_send(void);
void usart2_send(void);

void usart1_tx_fill(void);
void usart2_tx_fill(void);
void send_fill(void);


void test_gpio(void);

#endif
