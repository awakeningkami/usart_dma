#ifndef __ADC_H
#define __ADC_H

#include "main.h"

extern uint16_t g_rec_buf[8];
extern DMA_HandleTypeDef dma_handle;

void ADC_Init(void);

uint16_t adc_get_result(void);

#endif
